import { ethers } from 'ethers';
import inquirer from 'inquirer';
import chalk from 'chalk';
import fs from 'fs/promises';
import { loadChains } from '../network/manager.js';
import { getActiveWallet } from '../wallet/manager.js';
import { validateEthereumAddress, validateJSON } from '../utils/validation.js';

export const mintNFT = async () => {
  try {
    const chains = await loadChains();
    if (chains.length === 0) {
      console.log(chalk.red('No blockchain networks configured.'));
      return;
    }

    const wallet = await getActiveWallet();
    if (!wallet) {
      console.log(chalk.red('No active wallet found. Please create/select a wallet first.'));
      return;
    }

    // Select chain
    const { chainName } = await inquirer.prompt({
      name: 'chainName',
      type: 'list',
      message: 'Select blockchain network:',
      choices: chains.map(c => c.name),
    });
    const chain = chains.find(c => c.name === chainName);

    // Input NFT contract address
    const { contractAddress } = await inquirer.prompt({
      name: 'contractAddress',
      type: 'input',
      message: 'Enter NFT contract address:',
      validate: (input) =>
        validateEthereumAddress(input) ? true : 'Invalid Ethereum address.',
    });

    // Input ABI file path or JSON string
    const { abiInputType } = await inquirer.prompt({
      name: 'abiInputType',
      type: 'list',
      message: 'Provide NFT contract ABI as:',
      choices: ['Paste JSON', 'Load from file'],
    });

    let abiJSON;
    if (abiInputType === 'Paste JSON') {
      const { abiJsonString } = await inquirer.prompt({
        name: 'abiJsonString',
        type: 'editor',
        message: 'Paste the NFT contract ABI JSON:',
        validate: (input) =>
          validateJSON(input) ? true : 'Invalid JSON ABI.',
      });
      abiJSON = JSON.parse(abiJsonString);
    } else {
      const { abiFilePath } = await inquirer.prompt({
        name: 'abiFilePath',
        type: 'input',
        message: 'Enter path to ABI JSON file:',
        validate: async (input) => {
          try {
            const content = await fs.readFile(input, 'utf8');
            return validateJSON(content) ? true : 'Invalid JSON file.';
          } catch {
            return 'File not found.';
          }
        },
      });
      const content = await fs.readFile(abiFilePath, 'utf8');
      abiJSON = JSON.parse(content);
    }

    // Metadata URI
    const { metadataURI } = await inquirer.prompt({
      name: 'metadataURI',
      type: 'input',
      message: 'Enter metadata URI for your NFT:',
      validate: (input) =>
        input.trim() !== '' ? true : 'Metadata URI cannot be empty.',
    });

    // Setup provider and wallet signer
    const provider = new ethers.JsonRpcProvider(chain.rpcUrl);
    const signer = new ethers.Wallet(wallet.privateKey, provider);

    const contract = new ethers.Contract(contractAddress, abiJSON, signer);

    // Assume contract has a mint function of signature mint(address to, string metadataURI)
    console.log(chalk.yellow('Sending mint transaction...'));
    const tx = await contract.mint(wallet.address, metadataURI);
    await tx.wait();

    console.log(chalk.green(`NFT minted successfully on ${chain.name}!`));
    console.log(chalk.blue(`Transaction Hash: ${tx.hash}\n`));
  } catch (e) {
    console.log(chalk.red('Minting failed:'), e.message);
  }
};