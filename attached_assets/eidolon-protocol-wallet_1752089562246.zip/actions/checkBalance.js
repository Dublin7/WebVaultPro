import { ethers } from 'ethers';
import chalk from 'chalk';
import { loadChains } from '../network/manager.js';
import { getActiveWallet } from '../wallet/manager.js';
import inquirer from 'inquirer';

export const checkBalance = async () => {
  try {
    const chains = await loadChains();
    if (chains.length === 0) {
      console.log(chalk.red('No chains configured.'));
      return;
    }

    const { chainName } = await inquirer.prompt({
      name: 'chainName',
      type: 'list',
      message: 'Select blockchain network:',
      choices: chains.map(c => c.name),
    });

    const chain = chains.find(c => c.name === chainName);
    const wallet = await getActiveWallet();

    if (!wallet) {
      console.log(chalk.red('No active wallet found.'));
      return;
    }

    const provider = new ethers.JsonRpcProvider(chain.rpcUrl);
    const balance = await provider.getBalance(wallet.address);
    const eth = ethers.formatEther(balance);

    console.log(chalk.blueBright(`\nWallet: ${wallet.name}`));
    console.log(chalk.blueBright(`Address: ${wallet.address}`));
    console.log(chalk.green(`Balance on ${chain.name}: ${eth} ${chain.nativeSymbol}\n`));
  } catch (e) {
    console.log(chalk.red('Error checking balance:'), e.message);
  }
};