import { ethers } from 'ethers';

export const validateEthereumAddress = (address) => {
  try {
    return ethers.isAddress(address);
  } catch {
    return false;
  }
};

export const validateJSON = (jsonString) => {
  try {
    JSON.parse(jsonString);
    return true;
  } catch {
    return false;
  }
};

export const validateRPCUrl = (url) => {
  return /^https?:\/\/.+/.test(url);
};