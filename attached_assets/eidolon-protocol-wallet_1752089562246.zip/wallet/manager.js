import { Wallet } from 'ethers';
import fs from 'fs/promises';
import path from 'path';

const WALLETS_FILE = path.resolve('./config/wallets.json');

export const loadWallets = async () => {
  try {
    const content = await fs.readFile(WALLETS_FILE, 'utf8');
    return JSON.parse(content);
  } catch {
    return { wallets: [], activeWallet: null };
  }
};

export const saveWallets = async (data) => {
  await fs.writeFile(WALLETS_FILE, JSON.stringify(data, null, 2));
};

export const createWallet = async (name) => {
  const wallet = Wallet.createRandom();
  const walletData = {
    name,
    address: wallet.address,
    privateKey: wallet.privateKey,
    mnemonic: wallet.mnemonic.phrase,
  };

  const data = await loadWallets();
  data.wallets.push(walletData);
  data.activeWallet = name; // set new wallet active
  await saveWallets(data);

  return walletData;
};

export const selectWallet = async (name) => {
  const data = await loadWallets();
  if (!data.wallets.find(w => w.name === name)) {
    throw new Error('Wallet not found');
  }
  data.activeWallet = name;
  await saveWallets(data);
};

export const getActiveWallet = async () => {
  const data = await loadWallets();
  return data.wallets.find(w => w.name === data.activeWallet) ?? null;
};