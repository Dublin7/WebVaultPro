import fs from 'fs/promises';
import path from 'path';

const CHAINS_FILE = path.resolve('./config/chains.json');

export const loadChains = async () => {
  try {
    const content = await fs.readFile(CHAINS_FILE, 'utf8');
    return JSON.parse(content);
  } catch {
    return [];
  }
};

export const addChain = async (chain) => {
  // basic validation can be enhanced
  const chains = await loadChains();
  chains.push(chain);
  await fs.writeFile(CHAINS_FILE, JSON.stringify(chains, null, 2));
};