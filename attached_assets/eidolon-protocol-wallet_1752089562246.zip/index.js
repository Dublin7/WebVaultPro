import inquirer from 'inquirer';
import chalk from 'chalk';
import { createWallet, selectWallet, getActiveWallet, loadWallets } from './wallet/manager.js';
import { checkBalance } from './actions/checkBalance.js';
import { mintNFT } from './actions/mintNFT.js';

console.clear();
console.log(chalk.green.bold('\n== Eidolon Protocol Wallet ==\n'));

const mainMenuChoices = [
  'Create new wallet',
  'Switch wallet',
  'Check balance',
  'Mint NFT',
  'Exit',
];

const main = async () => {
  while (true) {
    const { action } = await inquirer.prompt({
      name: 'action',
      type: 'list',
      message: 'Choose action:',
      choices: mainMenuChoices,
    });

    if (action === 'Create new wallet') {
      const { walletName } = await inquirer.prompt({
        name: 'walletName',
        type: 'input',
        message: 'Enter a name for your new wallet:',
        validate: (input) => (input.trim() !== '' ? true : 'Name cannot be empty'),
      });
      const wallet = await createWallet(walletName);
      console.log(chalk.yellow('\nWallet created successfully!'));
      console.log(chalk.green(`Name: ${wallet.name}`));
      console.log(chalk.green(`Address: ${wallet.address}`));
      console.log(chalk.gray('Mnemonic and private key saved in config/wallets.json. Keep it safe!\n'));
    } else if (action === 'Switch wallet') {
      const walletsData = await loadWallets();
      if (walletsData.wallets.length === 0) {
        console.log(chalk.red('No wallets found. Please create one first.\n'));
        continue;
      }
      const { selectedWallet } = await inquirer.prompt({
        name: 'selectedWallet',
        type: 'list',
        message: 'Select wallet:',
        choices: walletsData.wallets.map(w => w.name),
      });
      await selectWallet(selectedWallet);
      console.log(chalk.green(`Switched to wallet: ${selectedWallet}\n`));
    } else if (action === 'Check balance') {
      await checkBalance();
    } else if (action === 'Mint NFT') {
      await mintNFT();
    } else {
      console.log(chalk.blue('\nGoodbye!\n'));
      process.exit();
    }
  }
};

main();