# Eidolon Protocol Wallet

A modular command-line Web3 wallet supporting multiple EVM-compatible chains and dynamic NFT minting on arbitrary contracts.

## Features

- Create and manage multiple wallets
- Switch active wallet easily
- Check native token balances on Ethereum, BSC, Polygon, and custom chains
- Mint NFTs on user-supplied contracts with ABI and metadata URI
- Configurable RPC endpoints and wallet storage

## Getting Started

### Prerequisites

- Node.js 18+ (for native ESM and latest ethers.js)
- npm or yarn package manager

### Install dependencies

```bash
npm install
```

### Usage

```bash
npm start
```

### Configuration

- `config/chains.json` — Add or modify supported chains here. Example:

```json
[
  {
    "name": "Ethereum",
    "chainId": 1,
    "rpcUrl": "https://rpc.ankr.com/eth",
    "nativeSymbol": "ETH"
  },
  {
    "name": "BSC",
    "chainId": 56,
    "rpcUrl": "https://bsc-dataseed.binance.org/",
    "nativeSymbol": "BNB"
  }
]
```

- `config/wallets.json` — Wallet storage (auto-created).

### Security Notice

Wallet private keys and mnemonics are stored in plain JSON locally. Keep `config/wallets.json` safe and do not share. Consider encrypting or integrating secure storage for production.

## License

MIT